package com.lee.test;

import android.content.res.AssetManager;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.util.DisplayMetrics;
import android.util.Log;

import java.io.File;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

/**
 * Created by lee.
 * Time 2017/2/21 15:56
 */

public class PluginResources extends Resources {
    public PluginResources(AssetManager assets, DisplayMetrics metrics, Configuration config) {

        super(assets, metrics, config);
    }

    public static AssetManager getAssetManager(File file, Resources resources) throws Exception {
        Class<?> aClass = Class.forName("android.content.res.AssetManager");
        Method[] methods = aClass.getDeclaredMethods();
        for(Method method : methods){
            if(method.getName().equals("addAssetPath")){
                AssetManager assetManager = AssetManager.class.newInstance();
                method.invoke(assetManager,file.getAbsolutePath());
                return assetManager;
            }
        }
        return null;
    }

    public  static PluginResources getPluginResources(AssetManager assetManager ,Resources resources){
        return  new PluginResources(assetManager,resources.getDisplayMetrics(),resources.getConfiguration());

    }
}

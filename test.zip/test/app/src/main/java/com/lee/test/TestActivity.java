package com.lee.test;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class TestActivity extends PluginActivity {


    @Override
    protected String setLayout() {
        return "activity_test";
    }

    @Override
    protected void initView() {
        try {
            ImageView iv = (ImageView) findViewByName("iv_test");
            Drawable ic2 = getDrawable("ic2");
            TextView tv = (TextView) findViewByName("tv");

            iv.setImageDrawable(ic2);
            tv.setText("我是插件,图片是插件里的图片");

            tv.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent i = new Intent();
                    i.setClassName("com.lee.test","com.lee.test.TwoActivity");
                    startActivity(i);
                }
            });

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

package com.lee.test;

import android.app.Activity;
import android.content.res.AssetManager;
import android.content.res.Resources;
import android.content.res.XmlResourceParser;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Environment;
import android.view.LayoutInflater;
import android.view.View;

import java.io.File;
import java.lang.reflect.Field;

/**
 * Created by lee.
 * Time 2017/2/23 16:00
 */

public abstract class PluginActivity extends Activity {

    protected Resources pluginResources;
    protected Class<?> layout;
    protected Class<?> mipmap;
    protected Class<?> id;
    private final static String APP_NAME = "app-debug.apk";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        try {
            initPlugin();
            initClass();
            setContentView(getInflate());
            initView();
        }catch (Exception e){
            e.printStackTrace();
        }

        super.onCreate(savedInstanceState);
    }

    /**
     * 获取当前布局
     * @return
     * @throws NoSuchFieldException
     * @throws IllegalAccessException
     */
    private View getInflate() throws NoSuchFieldException, IllegalAccessException {
        Field declaredFields = layout.getDeclaredField(setLayout());
        int activity_test = (int) declaredFields.get(layout);
        XmlResourceParser layout = pluginResources.getLayout(activity_test);
        return LayoutInflater.from(this).inflate(layout, null);
    }

    /**
     * 初始化R文件
     * @throws Exception
     */
    protected  void initClass() throws Exception {
        layout = loadClass("com.lee.test.R$layout");
        mipmap =loadClass("com.lee.test.R$mipmap");
        id = loadClass("com.lee.test.R$id");
    }

    protected  void initPlugin() throws Exception {
        AssetManager assetManager = PluginResources.getAssetManager(
                new File(Environment.getExternalStorageDirectory().getAbsolutePath() + File.separator + APP_NAME), getResources());
        pluginResources = PluginResources.getPluginResources(assetManager, getResources());
    }


    /**
     * 根据名字获取当前类
     * @param name
     * @return
     * @throws Exception
     */
    private Class loadClass(String name) throws Exception{

        return  getClassLoader().loadClass(name);
    }

    /**
     * 根据控件名称获取初始化当前控件
     * @param name
     * @return
     * @throws Exception
     */
    protected View findViewByName(String name) throws  Exception{
        Field iv_test = getField(id,name);
        return findViewById((int)iv_test.get(null));
    }

    /**
     * 根据图片名称获取图片
     * @param name
     * @return
     * @throws Exception
     */
    protected Drawable getDrawable(String name) throws Exception {
        Field ic2 = getField(mipmap,name);
        return pluginResources.getDrawable((int) ic2.get(null));
    }

    /**
     * 获取类中属性
     * @param clazz
     * @param name
     * @return
     * @throws NoSuchFieldException
     */
    private Field getField(Class clazz,String name)throws NoSuchFieldException{
        return clazz.getDeclaredField(name);
    }


    /**
     * 设置当前activity布局 
     * @return  布局名称
     */
    protected abstract String setLayout();

    /**
     * 在这里初始化
     */
    protected abstract void initView();

}

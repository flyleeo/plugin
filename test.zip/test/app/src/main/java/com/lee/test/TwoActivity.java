package com.lee.test;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

/**
 * Created by lee.
 * Time 2017/2/21 11:14
 */

public class TwoActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        TextView tv = new TextView(this);
        tv.setText("TwoActivity");
        tv.setTextSize(30);
        setContentView(tv);

        super.onCreate(savedInstanceState);
    }
}
